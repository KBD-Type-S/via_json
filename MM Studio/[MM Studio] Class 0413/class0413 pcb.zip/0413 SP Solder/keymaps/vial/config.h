/* SPDX-License-Identifier: GPL-2.0-or-later */
#pragma once

#define VIAL_KEYBOARD_UID {0x06, 0x12, 0x8C, 0x9F, 0xF0, 0xAE, 0x09, 0x5A}

#define DYNAMIC_KEYMAP_LAYER_COUNT 5