/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

/* Mechanical locking support. Use KC_LCAP, KC_LNUM or KC_LSCR instead in keymap */
#define LOCKING_SUPPORT_ENABLE
/* Locking resynchronize hack */
#define LOCKING_RESYNC_ENABLE

#define MATRIX_HAS_GHOST

#define DEBOUNCE 5     //读取引脚值时的延迟（默认为5）

/*
#define SOLENOID_PIN A8
#define SOLENOID_DEFAULT_DWELL 4
#define SOLENOID_MIN_DWELL 4
#define SOLENOID_MAX_DWELL  45
#define HAPTIC_OFF_IN_LOW_POWER 1
*/
#define SOLENOID_PIN A9
#define SOLENOID_DEFAULT_DWELL 45
#define SOLENOID_MIN_DWELL 4
#define SOLENOID_MAX_DWELL  100


#define AUDIO_CLICKY
#define AUDIO_PIN A8
#define AUDIO_PWM_DRIVER PWMD1
#define AUDIO_PWM_CHANNEL 1
#define NO_MUSIC_MODE                        

#define AUDIO_DAC_SAMPLE_MAX 4095U               //DAC通常以12Bit模式运行，因此100%的卷=4095U
#define AUDIO_CLICKY_FREQ_DEFAULT	1320.0f	     //设置点击声音的默认/开始音频频率。
#define AUDIO_CLICKY_FREQ_MIN	65.0f	         //设置最低频率（低于60f是有点bug）。
#define AUDIO_CLICKY_FREQ_MAX	1500.0f	         //设置最高频率。过高可能会导致同事攻击你。
#define AUDIO_CLICKY_FREQ_FACTOR	10.0f	 //设置向上/向下键代码的步进。这是一个乘法因子。默认情况下将频率向上/向下步进音乐小调三分之一。
#define AUDIO_CLICKY_FREQ_RANDOMNESS	0.0f	 //为单击设置随机性因子，将其设置为 0f会让每次点击都一样 1.0f会使这个声音很像90年代的电脑屏幕滚动/打字的效果。
#define AUDIO_CLICKY_DELAY_DURATION	 6       //整数音符的持续时间，其中1是速度的1/16，或64个音符,主点击效果将延迟此持续时间。将其调整到6-12左右的值将有助于补偿开关的音量过大。

/*
#ifdef AUDIO_ENABLE
    //#define STARTUP_SONG SONG(PLANCK_SOUND)
    // #define STARTUP_SONG SONG(NO_SOUND)

    #define DEFAULT_LAYER_SONGS { SONG(CAPS_LOCK_ON_SOUND),  \
                                  SONG(CAPS_LOCK_OFF_SOUND), \
                                  SONG(NUM_LOCK_ON_SOUND),   \
                                  SONG(NUM_LOCK_OFF_SOUND), \
                                  SONG(SCROLL_LOCK_ON_SOUND), \
                                  SONG(SCROLL_LOCK_OFF_SOUND) \
                                                            }
#endif
*/